print(r"dinejswar \n paswan") # ak row ko himprint ka dega ya ak line ko r laga dene se
print(r"Mohan\tand Sohan") # ak row ko himprint ka dega ya ak line ko r laga dene se
print(r"Mohan\tand \\t Sohan")