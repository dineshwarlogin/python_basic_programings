print("dineshwa \n paswan") # newline ya line break karnae keliye escape sequance ka use kiya jata hai \n
print("Ram and \t Syam his freinds") # sapace denekeliye \t ka use kiya jata hai
print("Mohan\tSohan") # sapace denekeliye \t ka use kiya jata hai
print("Gita\tandt\tSita") # sapace denekeliye \t ka use kiya jata hai
print("RamLa \\n khan") # dualbe back sales lagane se print hojaye naki line brak
print("sudha\\tRadha") # dualbe back sales lagane se print hojaye naki tab scape