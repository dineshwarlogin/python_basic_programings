#int =12 int data type hai isliye variable name int nahi rakh sakte
val=12
print(type(val))
print('this intiger variable= ',val)
