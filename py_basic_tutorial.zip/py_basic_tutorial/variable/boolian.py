#bool=true bool ko variavle name nahi rakh sakte hai keoki bool data type keyword hai
boo=True
bol= False
print(type(boo))
print("This is bool: ",boo)
print()
print(type(bol))
print("This is bool: ",bol)
