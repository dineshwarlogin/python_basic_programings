#float=54.00,45.01,1.5,5.4...... lekin ham variable name float nahi rakha sakte ye datatype hai
flo=12.00
age=45.00
sallary=1500.00

print(type(flo))
print("Thias is float: ",flo)
print("")
print(type(age))
print("This is float: ",age)
print("")
print(type(sallary))
print("This is float: ",sallary)