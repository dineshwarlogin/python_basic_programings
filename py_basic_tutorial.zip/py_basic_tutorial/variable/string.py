name="dineshwar"
titale="paswan"
age="32"
#string="2233paswan" string ya str data type hai isliye string ko variable name nahi rakha ja sakta hai
print(type(name))
print("This is staring variable:",name)
print()
print(type(titale))
print("This is staring variable:",titale)
print()
print(type(age))
print("This is staring variable:",age)