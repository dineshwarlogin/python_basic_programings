print()
age=10
age=age+20 # 10+20
print("Icrement ya Decrement ko hi assigNment oprator kaha jata hai :",age) #icrement ya decrement ko hi assigment oprator kaha jata hai,print hoga 30
print()
age1=100
age1+=500
print("100+500= ",age1) #icrement ya decrement ko hi assigment oprator kaha jata hai,print hoga 600
print()

s=1000
s-=100
print("1000-100= ",s) #icrement ya decrement ko hi assigment oprator kaha jata hai,print hoga 900
print()

s2=1000
s2=s2-300
print("1000 -300= ",s2) #icrement ya decrement ko hi assigment oprator kaha jata hai,print hoga 700
print()

s1=50
s1=s1*30
print("50X30= ",s1) #icrement ya decrement ko hi assigment oprator kaha jata hai,print hoga 1500
print()

s3=25
s3*=30
print("25X30= ",s3) #icrement ya decrement ko hi assigment oprator kaha jata hai,print hoga 750
print()

s3=25
s3/=5
print("25/5= ",s3) #assigment oprator kaha jata hai,print hoga 5.0
