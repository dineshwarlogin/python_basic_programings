a=15
b=15
if (a!=b): 
    print("yes")
else:
    print("no")