name="ram"
age=34
if name=="ram" and age==34:
    print("both same")
else:
    print("No both same")