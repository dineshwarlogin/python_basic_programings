a=800
b=450
if (a<b): 
    print(" A is less than of B")
else:
    print("no")