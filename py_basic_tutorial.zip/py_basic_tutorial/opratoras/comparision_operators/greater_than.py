a=200
b=1500
if (a>b): 
    print(" A is gtrater than of B")
else:
    print("no")