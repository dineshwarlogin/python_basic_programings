a=int(input("Enter The First Value: \n"))
b=50
if (a>=b):   
    print( "A is gtrater than of B Or A eual of B" ) # agar A>B se bara hoga ya fir A=B to candition chal jayega
else:
    print("no")