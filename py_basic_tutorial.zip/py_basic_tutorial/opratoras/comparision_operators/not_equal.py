a=30
b=20
if (a!=b): 
    print("yes")
else:
    print("no")