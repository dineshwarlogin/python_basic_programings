name="ram"
age=34
if name=="syam" and age=="40":
    print("both same")
else:
    print("No both same")