a=30
b=20
if (a==b): 
    print("equal")
else:
    print("no equal")