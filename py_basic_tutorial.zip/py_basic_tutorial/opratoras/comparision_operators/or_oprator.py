name="ram"
age=34
if name=="ram" or age=="34": # OR canditional do me se agar ak bhi sahi hua to progra chal jayega
    print("right")
else:
    print("worng")