a=int(input("Enter The First Value: \n"))
b=100
if (a<=b):   
    print( "A is less than of B Or A eual of B" ) # agar A<B se chota hoga ya fir A=B to candition chal jayega
else:
    print("no")