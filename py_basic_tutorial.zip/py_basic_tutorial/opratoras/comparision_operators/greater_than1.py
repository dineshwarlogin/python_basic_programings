a=200
b=150
if (a>b): 
    print(" A is gtrater than of B")
else:
    print("no")