a=10
b=10
if (a==b): 
    print("equal")
else:
    print("no equal")