a=30
b=20
c=a-b 
print(c) # 10 print hona chahiye
print()
x=50
x-=10
print(x) # 40 print hona chahiye
print()
y=500
y= y- 200
print(y) #300 print hona chahiye