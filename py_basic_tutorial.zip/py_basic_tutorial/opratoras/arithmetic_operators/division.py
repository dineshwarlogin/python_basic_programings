a=500
b=20
c=a/b 
print(c) # 25 print hona chahiye
print()
x=50
x/=10
print(x) # 5 print hona chahiye
print()
y=20
y= y/ 20
print(y) #1 print hona chahiye