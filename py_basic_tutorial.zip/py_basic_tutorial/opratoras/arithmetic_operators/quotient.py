a=51
b=20
c=a//b 
print(c) # 2 print hona chahiye
print()
x=55
x//=10
print(x) # 5 print hona chahiye
print()
y=20
y= y// 3
print(y) #6 print hona chahiye
print()
p=20
p= p// 7
print(p) #2 print hona chahiye