a=30
b=20
c=a+b 
print(c) # 50 print hona chahiye
print()
x=50
x+=10
print(x) # 60 print hona chahiye
print()
val=100
val= val+ 500
print(val) 