a=5**3 # 125 print hona chahiye
print(a)
print()
b=2
c=3
d=b**c
print(d) # 8 print hona chahiye
print()
x=4
x**=4
print(x) # 256 print hona chahiye
print()
y=20
y= y** 3
print(y) #800 print hona chahiye
print()
