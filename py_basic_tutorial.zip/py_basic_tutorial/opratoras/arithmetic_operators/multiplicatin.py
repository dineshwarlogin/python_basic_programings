a=5
b=20
c=a*b 
print(c) # 100 print hona chahiye
print()
x=50
x*=10
print(x) # 500 print hona chahiye
print()
y=20
y= y* 20
print(y) #400 print hona chahiye