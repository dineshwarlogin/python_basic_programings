a=510
b=20
c=a%b 
print(c) # 10 print hona chahiye
print()
x=55
x%=10
print(x) # 5 print hona chahiye
print()
y=20
y= y% 20
print(y) #0 print hona chahiye
print()
p=20
p= p% 3
print(p) #2 print hona chahiye