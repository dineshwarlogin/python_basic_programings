print() # blank print hoga
name="helo how are you gaiusse,its ok i am also fine"
nam="hare wrod ka first charector capital ho jayega"
print(name.title()) #hare wrod ka first charector capital ho jayega
print() # blank print hoga
print(nam.title())  # hare wrod ka first charector capital ho jayega