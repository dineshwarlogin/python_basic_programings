fn=int(input("Enter the f number: \n"))
sn=int(input("Enter the Second number: \n"))
total=fn+sn
print(total)

#print(f"First :\t{fn} & Second name:\t{sn} and age:\t{age}")