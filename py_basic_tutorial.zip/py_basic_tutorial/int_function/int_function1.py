fn=input("Enter the first number: \n")
sn=input("Enter the Seconde number: \n")
total=int(fn)+int(sn)
print(total)

#print(f"First :\t{fn} & Second name:\t{sn} and age:\t{age}")