print()
print("(string.center(with,[filchar]") # string.center(with,[fillchar]")
nam = "Sineshwar"
print(len(nam))
print("total lenth 9 hai,lekin 2 star age 2 star pichhe lagana chahte hai to lenth me 4 add kar denge ab lenth 13 hoga ")
nam2 = nam.center(14,"*") # total lenth 9 hai,lekin 2 star age 2 star pichhe laga chate hai to lenth me 4 add kar denge 
print(nam2)