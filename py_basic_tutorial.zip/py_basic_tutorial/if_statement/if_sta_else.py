a= 45
b=30
print()
if a==b:
    print("A and B, Both equal")
else:
    print("No,A and B, Both equal")  
a1=55
b1=80
if a1>b1:
    print("a1 is greater than of b1")
else:
    print("b1 is greater than of a1")