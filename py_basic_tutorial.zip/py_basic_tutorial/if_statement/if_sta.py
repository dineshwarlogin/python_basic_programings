a= 45
b=45
print()
if a==b:
    print("A and B, Both equal")
    
a1=55
b1=80
if a1<b1:
    print("b1 is greater than of a1")