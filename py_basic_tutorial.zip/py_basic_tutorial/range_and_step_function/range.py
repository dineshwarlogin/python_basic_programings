print()
print("This is range Syntxt1: (Start=0,Stop=10)") #Syntxt (start,stop)
val= range(0,10)
for i in val:
    print(i)
print()
print("This is range Syntxt2: (Start=0,Stop=6)") #Syntxt (start,stop)
val1= range(0,6)
for i in val1:
    print(i)
    
print("This is range Syntxt3: (Start=10,Stop=20)") #Syntxt (start,stop)
val2= range(10,20)
for i in val2:
    print(i)
    
print("This is range Syntxt4: (Start=14,Stop=20)") #Syntxt (start,stop)
val3= range(14,20,)
for i in val3:
    print(i)
    
print("This is range Syntxt5: (Start=2,Stop=10)") #Syntxt (start,stop)
for i in range(2,10):
    print(i)