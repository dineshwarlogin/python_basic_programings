print()
print("This is range Syntxt1: (Start=0,Stop=10,Step=3)") # Syntxt (Start,Stop,Step)
val= range(0,10,3)
for i in val:
    print(i)
print()
print("This is range Syntxt2: (Start=2,Stop=15,Step=3)") #Syntxt (start,stop,step)
val1= range(2,15,3)
for i in val1:
    print(i)
    
print("This is Range and Step Syntxt3: (Start=5,Stop=20,Step=4)")
val2= range(5,20,4)  # Syntxt (Start,Stop,Step),start=5,stop=20,step=5
for i in val2:
    print(i)
    
print("This is Range and Step Syntxt4: (Start=4,Stop=20,Step=5)")
val3= range(4,20,5)
for i in val3:
    print(i)