fn=input("Enter the Fist name: \n")
sn=input("Enter the Second name: \n")
age=int(input("Enter the Age in digit: \n"))

print(f"First name:\t{fn} & Second name:\t{sn} and age:\t{age}")
