fv=input("Enter the Fist Value: \n") # input function string me value print kata hai
sv=input("Enter the Second value: \n")
tv=input("Enter the  Third value: \n")

print(f"First value:{fv} and Seconf value:{sv} and Third value:{tv}")
