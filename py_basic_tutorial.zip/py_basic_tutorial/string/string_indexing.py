name="SIWANGI PASWAN"

print(name[0]) # S ko print karega
print(name[1]) # I ko print karega
print(name[2]) # W ko print karega
print(name[3]) # A ko print karega
print(name[4]) # N ko print karega
print(name[5]) # G ko print karega
print(name[6]) # I ko print karega
print(name[7]) # Blank ko print karega
print(name[8]) # P ko print karega
print(name[9]) # A ko print karega
print(name[10]) # S ko print karega
print(name[11]) # W ko print karega
print(name[12]) # A ko print karega
print(name[13]) # N ko print karega
print()
print(name[-1]) # string ka last position wala n print karega
print(name[-2]) # string ka second last a print karega
print(name[-3]) # third last w ko  print karega
print(name[-4]) #forth last s ko  print karega
print(name[-5]) #fift last a ko  print karega
print(name[-6]) #six last p ko  print karega
print(name[-7]) #seventh last blank ko  print karega
print(name[-8]) #eight last i ko  print karega
print(name[-9]) #nine last g ko  print karega
print(name[-10]) #ten last n ko  print karega
print(name[-11]) #eleven last a ko  print karega
print(name[-12]) #towelve last w ko  print karega
print(name[-13]) #thirtteen last i ko  print karega
print(name[-14]) #forteen last s ko  print karega





