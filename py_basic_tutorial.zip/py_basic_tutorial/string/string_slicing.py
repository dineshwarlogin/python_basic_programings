print()
print("(Start,End,Step:) yani ki kas se kaha tak appko print karna hai kitne step chor kar")
name="MYINDIA"
print(name[0:3]) # (start,end,step) yani ki kas se kaha tak appko print karna hai kitne step chor kar")

print(name[0:6]) # (start,end,step) yani ki kas se kaha tak appko print karna hai kitne step chor kar")
print(name[-4:])
print(name[3:5]) 





