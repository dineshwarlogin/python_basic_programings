fname="mohan"
lname="kumar"
print(fname +"" +lname)
print("")
nam="paswan"
age="54"
print(nam + age)
print()
val="56"
val1="100"
print(val+val1)
print()
a=90
b="78"
print(b+str(a))

