name="Siwangi"
print("Your name is: ",name)
print()
nam="Dineshwar"
age="34"
city="Bokaro"

print("Your name is: {0} and Age is: {1} and City name:{2}".format(nam,age,city)) #olld string formating
print()
print("Your name is: {2} and Age is: {0} and City name:{1}".format(nam,age,city)) #olld string formating
print()
print("Your name is: {1} and Age is: {2} and City name:{0}".format(nam,age,city)) #olld string formating
print()
print("Your name is: {} and Age is: {} and City name:{}".format(nam,age,city)) #olld string formating
print()
fname="Kirisana"
lname="Kumar"
print(f"First name: {fname} AND Last name:{lname}") #latest string formating
print("")


