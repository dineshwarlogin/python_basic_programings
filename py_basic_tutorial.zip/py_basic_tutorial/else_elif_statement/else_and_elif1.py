a= 45
b=45
c=20

print()
if a==b:
    print("A and B, Both are equal")
elif a<c:
    print("C is greateR than of A") 
else:
    print("A not eual of B and C is no greater than of A")
print()
a1=55
b1=80
c1=40
if a1>b1:
    print("a1 is greater than of b1")
elif a1>c1:
    print("a1 is greater than of c1")

elif a1>c1:
    print("a1 is greater than of c1")   
else:
    print("a1 is less than of b1, But a1 is greater than of c1")