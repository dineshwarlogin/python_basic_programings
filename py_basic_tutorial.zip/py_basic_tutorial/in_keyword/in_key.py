name="Dineshwar"
print()
print("in keywoard ka use nikalne ke liye kiya jata hai")
if "Dineshwar" in name: # in keywoard ka use nikale ke liye kiya jata hai
    print("YES Presente:",name)
else:
    print("NO Presente")
details="aman,paswan"

for a in details: # in kyword ka use for lop me jayada kiya jata hai
    print(a)
print()   
for i in range(5):
    print(i)

    