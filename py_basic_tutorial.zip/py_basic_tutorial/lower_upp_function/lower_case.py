print()
Fname="DINESHWAE"
Lname="PASWAN"
print(Fname.lower())  
print(Lname.lower())
print()

Fname="DINESHWAE"
Lname="PASWAN"
print(f"first name: {Fname.lower()} and Last name:{Lname.lower()}") 
