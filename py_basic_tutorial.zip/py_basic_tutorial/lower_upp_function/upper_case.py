print()
Fname="mahesh"
Lname="paswan"
print(Fname.upper())  
print(Lname.upper())
print()

Fname="danish"
Lname="viswakarma"
print(f"first name: {Fname.upper()} and Last name:{Lname.upper()}") 
