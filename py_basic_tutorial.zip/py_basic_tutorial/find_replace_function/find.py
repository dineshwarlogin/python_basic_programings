print()
str1="Old word city"
print(str1.find("w")) # (old string,new string)
name="Dineshwar paswan"
print(name.find("h"))
name="India is my countory"
print("m=",name.find("m"))
print(name.find("u"))
print("14=",name[14])
