print()
str1="Old word,New word"
print(str1.replace("Old word","New word1"))
name="Dineshwar paswan"
print(name.replace("Dineshwar","Mahesh"))
name="India is my countory"
print(name.replace("is my","you are"))