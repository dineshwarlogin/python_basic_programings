print("if and else if statement ka use nested satement multiple logical me kiya jata hai")
com=int(input("Enter the nnumber:\n"))
user=15 

if com == user:
    print("You Are Winear;")

elif com > user:
        print("Too High;")
else:
     print("Too Low;") 

    
    