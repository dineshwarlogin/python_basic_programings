print()
val="DINESHWAR308t77PASWA+@vg hun india horh bvjh jgyg hgfytsedyrhn"
print("total lenth: ",len(val))

v="yhkihjn cxfddtuiugdes"
print(len(v))