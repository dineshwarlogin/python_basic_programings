print()

print("program number: 1")
lists= ['apple','sony','sammsung','metrola','intex','gorila','micromax','redmi','relemi','jio']
ind=0
for i in (lists):
    print(ind,i)
    ind+=1
print(type(lists))

print()
print("Program Number: 2")
val=('Laptops','Computers','Radios','TVs','Mobiles')
for index, i in enumerate(val):
    print(index, "This is an electronice device name: ",i)  
print(type(val))

print()
print("Program Number: 3")
colors=("Red", "Green", "Blue", "Purple","Black","pinck","Yellow")
se_n=0
for i in (colors):
    
    print(se_n, "This is a color: ",i)
    se_n+=1 
print(type(colors))

