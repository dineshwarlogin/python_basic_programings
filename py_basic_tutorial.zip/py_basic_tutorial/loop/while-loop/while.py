#while True:       # while loop python me parmanante loop hota hai,
    #print("hello")       # while True: ye hamesa chalte hi rahega
print("Program Number :1")
i =5
while i<10:
    print("Hello feands:",i)
   
    i+=1 # jaise hi i value 5 se 10 ke braber hoga program break hojayega
print()   
print("Program Number :2")
k =1
while k<=4:
    print("Hello Gauise :",k)
   
    k+=1 # jaise hi i value 20 program break hojayega
print()   
print("Program Number :3")
j=0
while j<=3:
    print("I love From India :",j)
    j+=1
    #i+=1 # jaise hi i value 20 program break hojayega