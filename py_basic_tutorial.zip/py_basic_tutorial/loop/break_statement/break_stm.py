val=['1','2','3','4','5','6','7','8','9']
print("PROGRAM NUMBER :1,# jaise hi 5 milega program quite hojayega 1 to 4 tak print kar dega")
for i in val:
    if i == '5':
        break   # jaise hi 5 milega program quite hojayega 1 to 5 tak print kar dega
    print(i)
print()

print("PROGRAM NUMBER :2,jaise hi 7 milega program quite hojayega 0 to 6 tak print kar dega")
for i in range(10):
    if i==7:
        break # jaise hi 7 milega program quite hojayega 0 to 6 tak print kar dega
    print(i)
print()   

print("PROGRAM NUMBER :3, jaise hi 11 milega program quite hojayega 6 to 10 tak print kar dega")
n=20
i=5
while i <=n:
    i=i+1
    if i == 11:
        break   # jaise hi 11 milega program quite hojayega 6 to 10 tak print kar dega
    print(i)