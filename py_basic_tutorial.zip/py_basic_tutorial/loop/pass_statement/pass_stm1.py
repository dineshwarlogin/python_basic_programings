print("Program number :1")
a1 = 5
b1 = 10
if a1==b1:
    print("both same")
else:
    pass         #program chal jayega ,Blank print karega

print()

print("Program number:2")
a=20
b=20
if a!=b:
    pass  # YESS NAHI HAI, PROGRAM CHAL JAYEGA, Blank print karega
else:
    print("Both Same") 

print()

print("Program number:3")
a=20
b=12
if a!=b:
    pass # YESS NAHI HAI, PROGRAM CHAL JAYEGA  Blank print karega
else:
    print("its equale") 
print()

print("Program number:4")
for i in range(4):
    pass
print()

print("Program number:5")   
# for i in range(20):
    # program error dega, yani ki kuch na kuch print karana hi parega chahe balank hi keo na ho ya fir pass 