
a1 = 5
b1 = 10
if a1==b1:
    print("both same")
else:
    pass         #program chal jayega 
    