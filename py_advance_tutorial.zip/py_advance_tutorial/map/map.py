
print("\nmap:- map Fun ka Adhikans Squire Karne Me Use Karte Hai;")
print("\nPOROGRAM TYPE 1:-")
data=['5','10','7'] # string exchange in integer 
data=list(map(int,data))
print("This map fun in list format, string exchange in intiger: ",data)

print("\nPOROGRAM TYPE 2:- String value Exchange in Squire intiger with lambda")
data=list(map(lambda x:x*x,data)) # [x=5,x*x=>5*5=25, x=10,x*x=>10*10=100, x=7,x*x=>7*7=49] print karega Squire ME
print("This map fun in list format,string exchange in Squire intiger with lambda",data)

print("\nPOROGRAM TYPE 3:- String value exchange in Intiger with for loop")
data1=['15','20','13']# string exchange in integer 
for i in range(len(data1)):
    data1[i]=int(data1[i])
print("This map fun in list format, string exchange in intiger with forloop",data1)

print("\nPOROGRAM TYPE 4:- String value of List exchange in Tupple intiger") 
data2=tuple(map(int,data1))
print("This map fun in tuple format, String value of List exchange in Tupple intiger",data2)

print("\nPOROGRAM TYPE 5:- String value Exchange in Squire intiger with lambda")
data2=tuple(map(lambda x:x*x,data2))# [x=15,x*x=>15*15=225, x=20,x*x=>20*20=400, x=13,x*x=>13*13=169] print karega Squire ME
print("This map fun in tuple format, String value Exchange in Squire intiger with lambda",data2)


            