print("\nThis is map fun and use of squiring purpose:-")

data={"25":"5","36":"6","49":"7"}
print("\nProgram Type 1: ")
data1=list(map(int,data))
print("Key of Dict exchange in list",data1)

print("\nProgram Type 2:")
for i in range(len(data1)):
    data1[i]=str(data1[i])
print("list of intiger exchange in Tuple of String",tuple(data1))


print("\nProgram Type 3:")
data2=["36","80","64"]
for i in range(len(data2)):
    data2[i]=float(data2[i])
print("list of String exchange in Tuple of float",tuple(data2))

print("\nProgram Type 4:")
data2=list(map(lambda x:x-30,data2))
print("Tuple of float exchange in list of float with 30 decrement in all value: ",data2)

print("\nProgram Type 5:")
data2=tuple(map(lambda x:x%5,data2))
print("list of float exchange in tuple of float with 5 moduleter in all value:",data2)

print("\nProgram Type 6:")
data2=tuple(map(lambda x:x*20,data2))
print("list of float exchange in tuple of float with 20 multiply in all value:",data2)

print("\nProgram Type 7:")
data2=list(map(lambda x:x+100,data2))
print("Tuple of float exchange in list of float with 100 increament in all value",data2)

print("\nProgram Type 8:")
data2=tuple(map(lambda x:x*x,data2))
print("List of float exchange in Tuple of float with Squire in all value",data2)