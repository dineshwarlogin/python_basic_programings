
print("\nmap:- map Fun ka Adhikans Squire Karne Me Use Karte Hai;")

print("\nPOROGRAM TYPE 1:- String value of List exchange in Tuple Intiger with for loop")
data1=['15','20','13']     # string exchange in integer 
for i in range(len(data1)):
    data1[i]=int(data1[i])
print("['15','20','13']: ",tuple(data1)) #(15,20,13)

print("\nPOROGRAM TYPE 2:- Intiger value of Tuple exchange in String value of list with + 20 incremant in all value")
data2=map(lambda x: x+20,data1)  # (15=>15+20=35, 20=>20+20=40, 13=>13+20=33) # icrement of 20 in all value in tuple
data3=list(map(str, data2))
print("(15=>15+20=35, 20=>20+20=40, 13=>13+20=33): ",data3)

print("\nPOROGRAM TYPE 3:- String value of list Exchange in Intiger value Squire of Tuple with lambda")
data3=map(int,data3)
data4=tuple(map(lambda x:x*x,data3))  # [x='35',x*x=>'35'*'35'='1225', x='40',x*x=>'40'*'40'='1600', x='33',x*x=>'33'*'33'='1089']
print("[x='35',x*x=>'35'*'35'='1225', x='40',x*x=>'40'*'40'='1600', x='33',x*x=>'33'*'33'='1089']: ",data4)

print("\nPOROGRAM TYPE 4:- Intiger value of Tuple Exchange in String value of 10 multiply by list with lambda")

data5=map(lambda x: x*10,data4) #(x=1225, 1225*10=12250, x=1600,1600*10=16000, x=1089, 1089*10=10890) print karega
data5=list(map(str,data5))
print("(x=1225, 1225*10=12250, x=1600,1600*10=16000, x=1089, 1089*10=10890): ",data5)

            