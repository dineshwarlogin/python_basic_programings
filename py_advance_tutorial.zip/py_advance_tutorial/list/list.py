nam=['Dineshwae','Paswan','Engineer','Rs.85000',30,'Paswan','Rahul','Paswan']
st='manisa'
print("This is a: ",type(st))
list=list(st) # string convert hojayega list me
print("String convert hojaye ga list me: ",type(list))
print()
print("TYPE OF: ",type(nam)) #TYPE OF ko btayega
print()
print('List Print Hojayega: ',nam) # list ko hi print kar dega
print()
n=nam.count('Paswan')
print('This is an use count fun: ',n) # same value ko count kar lega
print()
print("This is an use index fun: indexing se accses kiya jata hai: ",nam[6]) # accses kiya jata hai kisi value ko
print()
print("This is use slicing fun: kaha se kaha tak: ",nam[2:5]) # kaha se kaha tak print krna hai
print()
nam.append('Manisa') # list ke last me add kar dega
print("This is use append fun: list ke last me add kar dega ",nam)
print()
nam[2]='Mohan' # change indexcing ho jayega 2 number index per mohan print ho jayega
print("This is use index fun: change indexcing",nam)
print()
del nam[4] # delete kar dega 4 number indexicing 
print("This use del fun: delete kar dega: ",nam)
print()
nam.remove('Rahul')  # delet ho jayega 
print("This is use remove fun: delet hojaye",nam)
print()
nam.pop() #pop hamesa last ka delet krta hai
print("This use pop fun: pop hamesa last ka delet krta hai",nam)
print()
last=['ANKIT',30,'PASWAN']  
nam= nam+last # dono list ko add kar dega
print("This use add list: 2 list ko add kar dega" ,nam)
print()
last=nam.copy() # nam variable ka sabhi data ko copy kr ke  last var me add kar dega, 
print("This use copy fun:-nam variable ka sabhi data ko copy kr lega: ",last)
print()
last[0]="Akush" 
print("Change Dikhega:",last) # 
print("Lekin Origanal data me koi change nahi dekhega:",nam)
print()
lis=["Rs.80500",50,"Usha","Nirmal"]
lis.extend(last) # lis var list me, last var ka data add kar dega
print("lis var list me last var list ka data ko exdend kar dega:",lis)
print()
for i in last:
    print(i)
print("This is use clear fun:- All data clear hojayega :",lis.clear())






