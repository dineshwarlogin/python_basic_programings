print("\nRECURSION:- function ke under function chala dena ya bar-bar ripitetion hona hi recursion kaha jata hai,")
def Teacher():
    print("Teacher is teching of Mathamatics,") # 
    def Student():
        print("Student learn math of Teacher,")
    Student()
Teacher()

print("Program Type 2: Ak hajar bar print karega")
def Teacher():
    print("Teacher is teching of Mathamatics,")
    #def Student():
        #print("Student learn math of Teacher,")
    #Student()
    Teacher() # isi ke chlate-->Teacher(): Ak hajar bar print karega recursion, keoki limit hai, ye bhi ak tarah ka error hi hai
Teacher()     # Ak hajar bar print karega recursion keoki limit hai, ye bhi ak tarah ka error hi hai
