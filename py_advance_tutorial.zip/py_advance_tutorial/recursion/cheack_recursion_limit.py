print("\nCHEACK RECURSION LIMIT PRINT 1000:-")

import sys
print("\nProgram Type 1, Verify Recursion limit 1000 print: ",sys.getrecursionlimit())

print("\nProgram Type 2, Bellow Recursion will be 1000 print:-")
def Teacher():
    print("nTeacher is teching of Mathamatics,")
    #def Student():
        #print("Student learn math of Teacher,")
    #Student()
    Teacher() # isi ke chlate-->Teacher(): Ak hajar bar print karega recursion, keoki limit hai, ye bhi ak tarah ka error hi hai
Teacher()     # Ak hajar bar print karega recursion keoki limit hai, ye bhi ak tarah ka error hi hai
