print("\nSET RECURSION LIMIT PRINT:- maximum 1000 tk fixed, minimum app chahe jitna set kar sakte ho;")
print("\nHow Can fixed Recursion Limit For The Print?, Bellow Recursion will be print upto 15:-")
import sys
sys.setrecursionlimit(15)
try:              # try ka use karte hai, error ko handal karne keliye taki user ko ak line me hi malum  chaljaye, agar error diya hai to,
    n=0
    def Teacher():
        global n
        n+=1
        print("nTeacher is teching of Mathamatics: ",n)
        Teacher() # isi ke chlate-->Teacher(): Ak hajar bar print karega recursion, keoki limit hai, ye bhi ak tarah ka error hi hai
    Teacher()     # 15 bar print karega recursion keoki limit set hai, ye bhi ak tarah ka error hi hai
except Exception as error: 
    print(error) # excep ko use error ko handal karne keliye taki user ko ak line me hi malum  chaljaye, nahi to bahut bara error deta hai

print("\nHow Can fixed Recursion Limit For The Print?, Bellow Recursion will be print upto 8:-")
import sys
sys.setrecursionlimit(8)
try:
    i=0
    def Student():
        global i
        i +=1
        print("Student learn math of Teacher: ",i)
        Student() # isi ke chlate-->  Student(): Ak hajar bar print karega recursion, keoki limit hai, ye bhi ak tarah ka error hi hai
    Student()     # 10 bar print karega recursion keoki limit set hai, ye bhi ak tarah ka error hi hai
except Exception as error:
    print(error)