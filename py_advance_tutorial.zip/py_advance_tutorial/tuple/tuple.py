print()
print("Tuple me update delet,remove not allowed, But list allowed in Tuple for rem,del,upd")
tup=()  # this is a tuple
print("Type of: ",type(tup))
lists=[34,"ram","man"]  # this is a list
t=tuple(lists)
print("list convert in tuple:",type(t))
t1=(10)     # this is intiger
print("This is a: " ,type(t1))
t2=(10,)    #this is tuple
print("This is a: ",type(t2))
t3=("10")    #this is string
print("This is a: ",type(t3))
t=(43,"mahesh","ramesh","ritu",55.00)
print("This is tuple:",t)
ran=range(10,15) #range
print("This  is range:",type(ran))
ran=tuple(range(10,15,))  #Range convert in tuple
print("Range convert in tuple:",type(ran))

print()
for i in ran:  # range me 10 ,11 ,12,13 ,14 tak pring karega last se -1 ghatadega
    print("This is range with for lop: ",i)
    
print()
for i in t:
    print("This is for loop with tuple:",i)
print()
print("This is indexing of 0: ",t[0]) # tuple me 4 number start karm per jobhi hoga  accsec kalenge
print("This is indexing of 1: ",t[1]) # tuple me 4 number start karm per jobhi hoga  accsec kalenge
print("This is indexing of 2: ",t[2]) # tuple me 4 number start karm per jobhi hoga  accsec kalenge
print("This is indexing of 3: ",t[3]) # tuple me 4 number start karm per jobhi hoga  accsec kalenge
print("This is indexing of 4: ",t[4]) # tuple me 4 number start karm per jobhi hoga  accsec kalenge
print()
data=(2,3,4,5,6,7,8,9,10,11,12)
print("This slicing  of 1 to 3: ",t[1:3]) # slicing start=1 to end=3 1 num serial to 3 num serial
print("This slicing of 3 to 8: ",data[3:8]) # slicing start=1 to end=3 1 num serial to 3 num serial
print()
print("Total you can get lenth  of tuple: ",len(data)) # you can get lenth of tuple
print("Total you can get lenth of tuple: ",len(t)) # you can get lenth of tuple
print("Total you can get lenth of list: ",len(lists)) # you can get lenth of list
print()
data1=(10,"ramu",60.00,["kamal","sony",80.50,200.00,"Rs.56000.00"],50,"babita") #list inside in tuple
print("indexing of 0 number serial:",data1[0])
print("indexing of 1 number serial:",data1[1])
print("indexing of 2 number serial:",data1[2])
print("indexing of 3 number serial:",data1[3]) # index se serial number ka pata chalta hai
print("indexing of 4 number serial:",data1[4])
print("indexing of 5 number serial:",data1[5])
print()
print("list inside in tuple,only modifiy in list:",data1)
data1[3].pop() # list ka last data delet kardega tuple meka
print("pop fun,list ka last data delet kar dega tuple me ka",data1) # tuple me del,upd,rem nahi kiya ja sakta hai,lekin tuple me list ka use kar ke upd,del,remove kar sakate ahi
data1[3].append("Dineshwar") # list ke last me add kar dega Dineshwar ko
print("append fun, list ke last me value add kar dega: ",data1)
data1[3].remove("sony") # list me se sony delet ho jayega
print("remove fun, sony deleted in list: ",data1) # list inside in tuple, only modifiy in list
data2=["sonu","rabi",10,30.06,] #exdend fun add kar dega,jor dega list ko list ya,dic ko dec se
data1[3].extend(data2)
print("exdend fun, add kar dega: ",data1)

print()
print("This is a maximume value: ",max(data)) # access karega maximum value
print("This is a maximume value: ",min(data)) # access karega minimume value
tuples=t + data # dono tuple will be added
print("2 tuple will be added: ",tuples)
lists.clear()
print("This clear list:",lists)
print()

data.clear() # tuple ko clear karne per wrong message dega
print("No allowed clear function in tuple:",data) # no allowed clear fun in tuple,