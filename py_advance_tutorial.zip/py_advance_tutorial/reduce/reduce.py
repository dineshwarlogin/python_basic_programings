print()
print("Reduce fun, all value ko lambda ke helpe se opration kar ke sort kar deta hai value ko")

from functools import reduce 
print("\nProgram Type 1:")
values=[10,10,30,40,50,60] # 10+10=>20+30=>50+40=>90+50=>140+60=200
values=reduce(lambda x,y: x+y,values) 
print("Reduce fun, all value ko lambda ke helpe se add kar deta hai: ",values) #result 200 hoga

print("\nProgram Type 2:")
values=[100,20,10,5,10,5]  #100-20=>80-10=>70-5=>65-10=>55-5=50
values=reduce(lambda x,y: x-y,values)
print("Reduce fun, all value ko lambda ke helpe se sub kar deta hai: ",values) # result 50 hoga

print("\nProgram Type 3:")
values=[2,3,5,4] # 2*3=>6*5=>30*4=120
values=reduce(lambda x,y: x*y,values)
print("Reduce fun, all value ko lambda ke helpe se multiplication kar deta hai: ",values) #result 120 hoga

print("\nProgram Type 4:")
data=(250,300,50,80,90,200) #250>300=n, 300>50=y, 300>80=y,300>90=y,300>200=y
data=reduce(lambda x,y: x if x > y else y,data)
print("Maximum value comparition kar ke pata kar sakte hai in reduce me: ",data) # result maximum 300

print("\nProgram Type 5:")
data=(250,300,50,80,90,200) 
data=reduce(lambda x,y: y if y < x else x,data)
print("Minimum value comparition kar ke pata kar sakte hai in reduce me: ",data) # result minimum 50

print("\nProgram Type 6:")
data=(25,241,500,880,970) 
data=reduce(lambda x,y: x%y,data)
print("Reduce fun, all value ko lambda ke helpe se moduler kar deta hai: ",data)

 