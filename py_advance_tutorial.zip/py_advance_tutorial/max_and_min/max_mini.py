print()
print("PROGRAM TYPE 1: LIST VALUE IN MAX & MIN:-")
a = [554,98,0.09,5.0,45,269,0.40,489,248] 
a = max(a)
print(f"Type-1:-The Maximmume Value is: {a}") # max and string format{} value with list

a = [554,98,0.09,5.0,45,269,0.40,489,248]
a = min(a)
print(f"Type-1:- The Minimmume Value is: {a}") # min and string format{} value with list
print()

print("PROGRAM TYPE 2: TUPLE VALUE IN MAX & MIN:-")
a =(205,668.06,565,2748,4098,268,500.60,510) 
print("Type-2:- The Maximmume Value is:",max(a)) # maximume  value with tuple
print("Type-2:- The Minimmume Value is:",min(a)) # minimume value with tuple
print()

print("PROGRAM TYPE 3: DICTIONARY VALUE INSIDE LIST IN MAX & MIN WITH LAMBDA:-")
data =  [
        {'Computer':'Sony','Ram':'75gb','Price':'Rs.505000','OpratingSystem':'linex'},
        {'Computer':'Leneo','Ram':'25gb','Price':'Rs.250000','OpratingSystem':'windows'},
        {'Computer':'Compaqe','Ram':'20gb','Price':'Rs.7000000','OpratingSystem':'Unix'},
        {'Computer':'Accer','Ram':'65gb','Price':'Rs.850000','OpratingSystem':'Safari'},
        ]

print("Type-3:-Maximmume Price of Computer:",max(data, key = lambda item:item.get('Price'))["Computer"])
print("Type-3:-Minimmume Price of Computer: ",min(data, key = lambda item:item.get('Price'))["Computer"])

print("Type-3:-Max Price OF OpSystem: ",max(data, key = lambda item:item.get('Price'))["OpratingSystem"])
print("Type-3:-Min Price OF OpSystem: ",min(data, key = lambda item:item.get('Price'))["OpratingSystem"])

print("Type-3:-Maximmume Ram OF Computer: ",max(data, key = lambda item:item.get('Price'))["Computer"])
print("Type-3:-Minimmume Ram OF Computer: ",min(data, key = lambda item:item.get('Price'))["Computer"])
print()

print("PROGRAM TYPE 4: DICTIONARY VALUE INSIDE DICTIONARY IN MAX & MIN WITH LAMBDA:-")
data1 = {
        "SAMSSUNG": {"PRICE":2500},
        "REDMI"   : {"PRICE":54000},
        "METROLA" : {"PRICE":32000},
        "RELMI"   : {"PRICE":46000},
        "NOKIA"   : {"PRICE":340500}
        }

print("Type-4:-Maximmume Value of Mobile: ",max(data1, key = lambda item:data1[item]['PRICE']))
print("Type-4:-Minimmume Value of Mobile: ",min(data1, key = lambda item:data1[item]['PRICE']))
print()

print("PROGRAM TYPE 5: DICTIONARY VALUE INSIDE DICTIONARY IN MAX & MIN WITH LAMBDA:-")
data2= (
      {"NAME": "DINESHWAR","AGE":30,"DEGINATION":"ENGINEER","SALLARY":80500},
      {"NAME": "RADHA","AGE":46,"DEGINATION":"ADVOCATE","SALLARY":68000},
      {"NAME": "MONIKA","AGE":70,"DEGINATION":"MANAGER","SALLARY":40800},
      {"NAME": "ANJU","AGE":27,"DEGINATION":"ASISTANT","SALLARY":28500},
      {"NAME": "PRATAP","AGE":50,"DEGINATION":"EXCUTIVE","SALLARY":14800}
      )
print("Type-5:-Maximmume Sallary Of: ",max(data2,key = lambda item:item.get("SALLARY"))["NAME"])
print("Type-5:-Minimmume Sallary Of: ",min(data2,key =lambda item:item.get("SALLARY"))["NAME"])

print("Type-5:-Maximmume Age Of: ",max(data2,key = lambda item:item.get("AGE"))["NAME"])
print("Type-5:-Minimmume Age Of: ",min(data2,key =lambda item:item.get("AGE"))["NAME"])

print("Type-5:-Maximum Sallary Of Degination: ",max(data2,key = lambda item:item.get("SALLARY"))["DEGINATION"])
print("Type-5:-Minimum Sallary Of Degination: ",min(data2,key =lambda item:item.get("SALLARY"))["DEGINATION"])

print("Type-5:-Maximmume Age Of: ",max(data2,key = lambda item:item.get("AGE"))["DEGINATION"])
print("Type-5:-Minimmume Age Of: ",min(data2,key =lambda item:item.get("AGE"))["DEGINATION"])

print("Type-5:-Maximmume Name Of Age: ",max(data2,key = lambda item:item.get("NAME"))["AGE"])
print("Type-5:-Minimmume Name Of Age: ",min(data2,key =lambda item:item.get("NAME"))["AGE"])

