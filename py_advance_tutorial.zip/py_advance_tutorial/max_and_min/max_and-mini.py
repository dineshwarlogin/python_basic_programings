print()
print("Program -1:: Get String Lenth of Charecters in Max and Min Function:-")

def max_mini_value(item):
    return len(item)

values= ["WELLECOME", "INDIA", "he", "gauiss", "MOST", "INDIA","IndianMainsVerySmart"]
max_value = max(values,key=max_mini_value)
mini_value = min(values,key=max_mini_value)


print("Type-1:- The Maximmume Lenth of Charecters:",max_value) # maximume  lenth of str char with list 
print("Type-1:- The Minimmume Lenth of Charecters:",mini_value) # minimume lenth of str char with list 
print()

print("Program -2:: Get String Lenth of Charecters in Max and Min Function:-")
def max_mini(item):
    return len(item)

values= ["WELLECOME INDIA", "he gauiss", "MOST INDIA","Indian Mains Very Smart"]
max_value = max(values,key=max_mini)
mini_value = min(values,key=max_mini)


print("Type-2:- The Maximmume Lenth of Charecters:",max_value) # maximume  lenth of str char with list 
print("Type-2:- The Minimmume Lenth of Charecters:",mini_value) # minimume lenth of str char with list 

