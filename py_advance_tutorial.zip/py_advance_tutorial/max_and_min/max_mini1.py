
print("\nProgram Type 5")
data2 = {
        "HP"    : {"LAPTOP":30688,"RAM":10},
        "SONY"  : {"LAPTOP":150688,"RAM":16},
        "DELL"  : {"LAPTOP":60688,"RAM":40},
        "ACCER" : {"LAPTOP":40688,"RAM":8}
        }
print("This is maximume OF RAM:",max(data2,key=lambda item:data2[item]["RAM"]))
print("This is minimume OF RAM: ",min(data2,key=lambda item:data2[item]["RAM"]))

print("\nThis is maximume Price OF Laptop: ",max(data2,key=lambda item:data2[item]["LAPTOP"]))
print("This is minimume Price OF Laptop: ",min(data2,key=lambda item:data2[item]["LAPTOP"]))
