print()
val={"Computer":"SONY","Ram":"4GB","Hard_Disk":"500GB","Price":"Rs.55000"}
lists=[]
print("This is :",type(lists))
dic=dict(lists)
print("List ko Dictionary me convert: ",type(dic)) # list ko dictionary me convert

print("This is a: ",type(val))
print("This is Dictionary: ",val)
print("Ram of: ",val["Ram"])           #dexcing se get kar sakte hai value ko
val['Computer']="Sammsung"      # indexcing ko change bhi kar sakte hai 
print("Updated key value with the help of indexcing  :",val)
for i in val.values():             # value get karne ke liye variableName.values()
    print("This get value of dictionary: ",i)
    
for i in val.items():           # items get karne ke liye variableName.items()
    print("This items of Result in Tuple: ",i)
    
for i in val.keys():         # key value ko print karega
    print("This is get key of dictionary: ",i)
    
if "Ram" in val:  #type 1  in keword ka use cheack me kiya jata hai if else ke sath
    print("YES, Persente type 1")
else:
    print("NO, Persente type 1")
    
if "Price" in val.keys():   # type 2, in keword ka use key ko cheack karsakte ho,
    print("YES, Persente Key type 2")
else:
    print("NO, Persente Key type 2")
    
if "500GB" in val.values():   # type 2, in keword ka use value ko cheack karsakte ho,
    print("YES, Persente Value type 3")
else:
    print("NO, Persente Value type 3")
if "4gb" in val.values():
    print("YES, Persent value,type 4")
else:
    print("NO, Persente Value type 4") # value nahi match karega iliye else conditinal chal jayega
val2={"OpratingSyt":"windows","Screen size":"18in"}
val.update(val2) # val2 variable ka data val variable me ak new dic me update ho jayega
print("val2 dic ko val dic me updated :",val)
del val['Price']  # only delet key name, your data will be deleted, not use key value delet,your data will not deleted
print("Deleted of Price:",val) 
val.pop('Ram')    # pop ko dictionary me key name se delet kiya jata hai, 
print("POP fun use Deleted of 4GB:",val)
v=val.get('Screen size')    # get fun se key value ko acceses kar sakte hai, 
print("Get fun se key value ko acceses kar sakte hai, Screen size: ",v)
val.clear()  #  clear kar dega dictionary ko
print("This Dictionary is clear:",val)
val2.clear()  #  clear kar dega dictionary ko
print("This Dictionary is clear:",val2)

    

