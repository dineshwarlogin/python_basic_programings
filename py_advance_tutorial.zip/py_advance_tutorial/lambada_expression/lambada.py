print("lambda ka use agar hame lagta hai ki ak hi line me samat karna hai prograam to lambda ka use kiya jata hai\n lambada ak ka koi nam nahi hai")

add=lambda x,y:x+y # x=30,y=90
print("This is a lambda used in 2 value for add: ",add(30,90)) #30+90=120

mul=lambda x,y:x*y #x=10,y=6
print("This is a lambda used in 2  value for multiplication: ",mul(10,6)) # 10*6=60

div=lambda x,y:x/y # x=100,y=5
print("This is a lambda used in 2  value for divitional:",div(100,5)) # 100/5==> 20
print()

add=lambda x,y,z:x+y+z # x=30,y=90,z=20
print("This is a lambda used in 3 value for add: ",add(30,90,20)) #30+90+20=140

mul=lambda x,y,z:x*y*z #x=10,y=6,z=5
print("This is a lambda used in 3 value for multiplication: ",mul(10,6,5)) # 10*6*5=300

div=lambda x,y,z:x/y/z # x=100,y=5,z=4
print("This is a lambda used in 3 value for divitional:",div(100,5,4)) # 100/5==> 20/4=5