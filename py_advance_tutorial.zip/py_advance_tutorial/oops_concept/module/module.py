print("\nModule ka use:- jab hame lagta hai ki code bahut bara hone wala hai,ya file multiple hone wala hai, tab ham file ko sepreat karne ke liye alag file folder ka use karte hai:-")
def Add(a,b,c):   #-------- program ---------1
    return a+b+c
def Sub(a,b,c):
    return a-b-c
def Mul(a,b):
    return a*b
def Div(a,b):
    return a/b

class mobile():  #-------- program ---------2
    def __init__(self, *args):
        print("Moble is Electronice devices and Constructor")
        
    def __del__(self):
        print("This is deconstructor")
        
class Bike:  #-------- program ---------3
    def Hero(self):
        print("This is hero honda bike")
    def Suzuki(self):
        print("This is a Suzzuki Bike")
    def Bike_fun(self,start,color,eng,milleg,price):
        return start, color, eng, milleg, price
Bike()
class Detaills():  #-------- program ---------4
    def Boys(self,name,age,city):
        print(f"Your Name: {name} and Your age: {age} From: {city}") # string format{} kahte hai
    def Girls(self,name,age=20,city="Ranchi"): #overloading funtion ko polymorephism kahte hai
        return name, age, city
    def Moduleter(self,a,b):
        print(f"Tatal value: {a} % {b}:",a%b)
Detaills()