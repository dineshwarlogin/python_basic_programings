import module    # filename(module) module file ka name hai jo impor kiya gya hai
from module import Add       # --------program ---------1
from module import Sub
from module import Mul
from module import Div # --------program end---------2
from module import mobile    # --------program ---------2
from module import Bike      # --------program ---------3
from module import Detaills  # --------program ---------4

#import base/from base import Student
import base  # FileName(base) base file ka name hai jo impor kiya gya hai, ----program ----5

print("POROGRAM TYPE 1:-") 
print("Addition Totale value:",Add(25,80,56))   # --------program ---------1
print("Subtraction Totale value:",Sub(25,80,56))
print("Multiplication Totale value:",Mul(80,20))
print("Division Totale value:",Div(2500,25)) # --------program end---------1

print("\nPOROGRAM TYPE 2:-") 
mobile() # object 1, call hojayega   # --------program srat/end---------2

print("\nPOROGRAM TYPE 3:-") 
B=Bike() # object 2, call hojayega  # --------program start---------3
B.Hero()
B.Suzuki()
print("Bike Detaills:",B.Bike_fun("Start:Self and kik","Color:Read","Einggine:125CC","Millege:75KMH","Price:Rs.87500"))
                                   # --------program end---------3
print("\nPOROGRAM TYPE 4:-") 
D=Detaills() #object 3, call hojayega  # --------program  sart---------4
D.Boys("Dineshwar",31,"Sasaram")
D.Boys("Mohit",26,"Bokaro")

print(D.Girls("Priyanka"))
print(D.Girls("Khusbu",25,))
print(D.Girls("Annu",30,"Dhanbad"))

D.Moduleter(216,5)                   # --------program end---------4

print("\nPOROGRAM TYPE 5:-")                # --------program sart ---------5
#fileaName.objectName.propertiesName
print(f"Your name: {base.S.name} and Your age:{base.S.age} from : {base.S.cty}")

base.S.Manger("ALOCK PASWAN",25,"BIKRAMGUNJ")
base.S.Manger("KIRISH KUMAR",18,"BOXER")
base.S.Manger("SASHIKANT",30,"GOPALGUNJ")

print("Engineer Details: ",base.S.Engineer("BIKAS",45,"DELHI","Rs.50500")) 
print("Engineer Details: ",base.S.Engineer("RAMAN",35,"PUNE","Rs.70500"))
print("Engineer Details: ",base.S.Engineer("SUNIL",25,"MUMBAI","Rs.90500"))

print("Science Student Details: ",base.S.Science("BINDO",500,"RANCHI",))
print("Science Student Details: ",base.S.Science("PRITY",40,"GUMLA",19000))
    
print("Arts Student Details: ",base.S.Arts("PASWAN",102,"TATA"))
print("Arts Student Details: ",base.S.Arts("PRITY",40,"GUMLA",19000))