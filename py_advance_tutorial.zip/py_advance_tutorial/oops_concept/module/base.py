class Employee:      # Super class
    name="Dineshwar"
    age=25
    cty="Bokaro"
    def Manger(self,name,age,cty):
        print(f"Name of Manager:{name} and Age:{age} From: {cty}")

    def Engineer(self,name,age,cty,sallary):
        return name,age,cty,sallary
class Student(Employee):  # Base class
    def Science(self,name,rol,city,fee=150600,):
        return name,rol,city,fee
    
    def Arts(self,name,rol,city,fee=70600,):
        return name,rol,city,fee
S=Student()
        