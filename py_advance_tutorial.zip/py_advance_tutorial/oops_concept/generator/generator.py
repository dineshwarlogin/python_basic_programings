from typing import Generator


print("\nThis is generator ka istmal bahut bara jab data ko print karna ho tab use kare keoki fat kam karta ha :")
def gen(a):
    yield a
a=10000
for i in gen(a):
    print(i)
