from typing import Generator


print("\nThis is generator ka istmal bahut bara jab data ko print karna ho tab use kare keoki fat kam karta ha :")
def Reverce(mystr):
    length= len(mystr)
    for i in range(length - 1,-1,-1):
        yield mystr[i]

for CHAR in Reverce("DINESHWARPASWANHELOINDIA"):
    print(CHAR)



