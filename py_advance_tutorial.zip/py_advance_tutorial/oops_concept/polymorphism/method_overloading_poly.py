print("\nThis is Method Overloding Polymorphism:- Method overloading me class ko use kiya jata hai")

# a=10,b=90,c ka value 10,pass kar dega isiko playmorepisam kahate hai

class Student: 
    def Dinesh(self,name,age="10",title="Paswan"): # 3 arigement pas kiya gya hai
        return name,age,title
    
    def Manis(self,name,age,title="kumar"): # title defult arigemnet hai
        return name,age,title
    def Add_Value(self,a,b=-10,c=30):       #b,c defult airgement hai
        return a+b+c
    def Sub_Value(self,a,b=-10,c=30):       #b,c defult airgement hai
        return a-b-c
        
S=Student() 
print("Your information: ",S.Dinesh('DINESHWAR')) # Ager 2 arigement nahi pas karenge to defult ka dono value lelega,
print("Your information: ",S.Manis("AMAR","40",)) # Ager 1 arigement nahi pas karenge to defult ka ak value lelega,
print("Addition Thee Value: ",S.Add_Value(40)) # Ager 2 arigement nahi pas karenge to defult ka ak value lelega,
print("Subtraction Thee Value: ",S.Sub_Value(100)) # Ager 2 arigement nahi pas karenge to defult ka ak value lelega,
