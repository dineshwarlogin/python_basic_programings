print("\nThis is Funtion Overloading Polymorephism,Fun Overloading me multiple funtion ko use karsakte hai:-")
print("Program Type 1:-")
def Data(a,b,c=50):
    return a+b+c
D=Data(10,90)    # a=10,b=90, c ka Defult value 10 hai,agar c value nahi diye to defult c pass kar dega isiko playmorepisam kahate hai
print(f"Totale value: ",D) # 110
D=Data(90,20,50)
print("Totale value: ",D)

print("\nProgram Type 2:-")
def Computer(a,b,c):
    return a,b,c
print("Computer Details 2:",Computer("Samssung", "Ram=8gb","Rs.58000"))

print("\nProgram Type 3:-")
def Computer1(name="Sony",ram="4GB"):
    return name, ram,
print("Computer Details 3:",Computer1()) # dono defult airgement pass ho jayega

print("\nProgram Type 4:-")
def Computer4(price,name="Dell",ram="8GB"):
    return name, ram,price  # return me airgement jis karm me denge usi karam print karega
print("Computer Details 4:",Computer4(50800)) # dono defult airgement pass ho jayega

print("\nProgram Type 5:-")
def Computer4(price,name,ram,):
    return price,name, ram,    # return me airgement jis karm me denge usi karam print karega
print("Computer Details  5:",Computer4(50800,"10GB","PHP")) #passing value, jis karm me airgement hoga usi karma me pass kar dega

