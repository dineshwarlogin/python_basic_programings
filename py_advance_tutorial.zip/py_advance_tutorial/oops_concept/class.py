print()
print("Class is Define Data Type:-\n")
print("Program Type-1:")
class School:
    print("Schoole is class name")
School()
print()

print("Program Type-2: class with object used:")
class Employee():
    age=50                # Class variable hai
    name="Dineshwar"      # Class variable hai
    sallary=650600.00     # Class variable hai
EMP=Employee() # object kahate hai
print(f"Your age:{EMP.age} and Your name:{EMP.name}, and Your sallary:{EMP.sallary}") 
print()

print("Program Type-3: I used class and fun/method with object:")
class Employee():
    age=50               # Class variable hai
    name="Dineshwar"     # Class variable hai
    sry=650600.00        # Class variable hai
    dep="Banking"        # Class variable hai
    degi="Maneger"       # Class variable hai
    def deparment(self): # function/method kahate hai
        pass
EMP=Employee() # object kahate hai
print(f"Your age:{EMP.age} \nYour name:{EMP.name}\nYour sallary:{EMP.sry}\nYour deparment:{EMP.dep}\nYour deginationa:{EMP.degi}")
print()

print("Program Type-4: I used class and fun/method with object:")
class Student():
    art=("I.Ats","BA","MA")        # Class variable hai
    science= ["I.Science","B.Tech","BCA","MCA","M.Tech","BAC","MAC","Diplopma"]# Class variable hai

std=Student() # object kahate hai
upd=Student() # object kahate hai
print("Art Cource:",std.art)
print("Science Cources:",std.science)
print()
upd.art=("Intermediate Arts","Batchelor of Arts","Master of Arts") #instance variable kahate hai
upd.science=("LLB","MFIL","MBA","BBA","Medicals")  #instance variable kahate hai
print("Cource is Arts:",upd.art) 
print("New Cources Of Science:",upd.science)
print()
print("Instance Variable class variable ko change nahi kar sakta hai:-")
print("Art Cource:",std.art) # Instance Variable class variable ko change nahi kar sakta ha
print("Science Cources:",std.science) # Instance Variable class variable ko change nahi kar sakta ha


