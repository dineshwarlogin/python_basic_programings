print()
print("\nFile Handling Different Type Use Work:-like file open/write/read/remove/colose;")
print("You Can Read File content in For Loop:-")
file = open("file1.txt","r+") #("fileName.txt","mode") "r+"-> mode me read and write dono hota hai

file = open("file1.txt","r+")
for f in file:   # you can read file
    print("\nProgram 1,Show Data:\n",f)


file.close()
f = open("file1.txt","r+")
print("\nProgram 2,Total 20 content lenth :",f.read(20)) #20 lenth tak print kar dega
file.close()

f = open("file1.txt","r+")
print("\nPROGRAM 3,SHOW DATA:",f.read())  # you can read file
          #OR
#file.writable("helo dineshwar paswan")




