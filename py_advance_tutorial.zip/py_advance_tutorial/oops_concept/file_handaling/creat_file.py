print()
print("\nFile Handling Different Tpye Use Work:file open/write/read/colose/remove:-")
file = open("file1.txt","x")  # open("fileName.txt","mode") "x"-> mode use creat file
print("file is creted:",file) # your file is created of this name(file1.txt)
#and written hera in file
file.write("Wellcome in my contry, Most Wellcom my dear, How are you, i am also fine and You,")# aapke file me likhajayega


