print()
print("\nFile Handling Different Tpye Use Work:file open/write/read/colose/remove:-")
file = open("file.txt","r+") #("fileName.txt","mode") "r+"-> mode me read and write dono hota hai
f=file.write("Mister Dineshwar Please visit my company tomorou") # you can write heare
print("SHOW DATA:-",file.read(f))  # you can read heare




