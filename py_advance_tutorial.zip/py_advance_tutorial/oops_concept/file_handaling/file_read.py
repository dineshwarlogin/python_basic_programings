print()
print("\nFile Handling Different Tpye Use Work:file open/write/read/colose/remove:-")
file = open("file1.txt","r+") #("fileName.txt","mode") "r+"-> mode me read and write dono hota hai
print("SHOW DATA:",file.read())  # you can read
#file.writable("helo dineshwar paswan")



