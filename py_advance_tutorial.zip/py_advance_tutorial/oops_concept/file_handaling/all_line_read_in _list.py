print()
print("***SMART CODING,ALL LINE READ IN LIST**:-")
with open("file.txt","rt") as file:  #("fileName.txt")  open file for read
    f=file.readlines()
    print("Show Content Heare: \n",f)  # you can read heare
    file.close() # # open karne ke bad file ko close kar dena chahiye





