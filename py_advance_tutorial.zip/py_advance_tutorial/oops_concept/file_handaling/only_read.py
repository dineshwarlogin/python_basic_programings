print()
print("***SMART CODING FOR READ AND WRITE**:-")
with open("file.txt") as file:  #("fileName.txt")  open file for read
    f=file.read()
    print("Show Content Heare: ",f)  # you can read heare
    file.close() # # open karne ke bad file ko close kar dena chahiye





