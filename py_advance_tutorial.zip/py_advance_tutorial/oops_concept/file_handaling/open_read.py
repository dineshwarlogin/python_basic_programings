print()
print("\nSHOW CONTENT IN STRING FORMAT:-")
file = open("file1.txt","rb") #("fileName.txt","mode") "rb"-> mode ka use string me read keliye
#f=file.read()
#print("Show Data in String Frrmat:",f)  # you can read
    #   OR
print("Show Data in String Frrmat:",file.read())  # you can read
file.close()



