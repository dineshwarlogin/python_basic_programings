print()
print("\nFile Handling Different Tpye Use Work:file open/write/read/colose/remove:-")
file = open("file.txt","x")  # open("fileName.txt","mode") "x"-> mode use creat file
print("file is creted:",file) # your file is created of this name(file1.txt)
file.close() # open karne ke bad file ko close kar dena chahiye


