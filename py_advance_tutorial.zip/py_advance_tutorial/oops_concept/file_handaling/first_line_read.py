print()
print("***SMART CODING, YOU CAN ONLY FIRST LINE READ **:-")
with open("file.txt","rt") as file:  #("fileName.txt")  open file for read
    f=file.readline() # You can only first line read,
    print("Show Content Heare: \n",f)  # you can read heare
    file.close() # # open karne ke bad file ko close kar dena chahiye





