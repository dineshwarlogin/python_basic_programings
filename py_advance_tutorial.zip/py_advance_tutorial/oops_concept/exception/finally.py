print("\nFinally ka use:-user ko lagta hai ki jab file open hua hai to file ko to close karna hi hoga, nahi to file open nahi hai ya is name ka file nahi hai to error chal jayega:-")

print("\nPROGRAM TYPE 1:'w+'mode me agar file me pahale se data hai to file ko clean kar dega,new data uske jaga per likha jayega,jo aap likhana chahte hai:-\n") 
try:     # ager sahi hoga to Try chal jayega 
    f = open("demofile4.txt","w+")  # "w+"-> agar file me pahale se data hai to file ko clean kar dega,new data uske jaga per likha jayega,jo aap likhana chahte hai
    f.write("wellcome fornaer mane in idias.helo indian boys")# ager sahi hoga to Try chal jayega
    R=f.read()
    print("Show Content:",R) 
    
except:  # nahi to except chaljayega
    print("Not Avilable File or Not Oppen file") 
finally:
    f.close() # file open hua to file ko closed karega hi,
