print("\nFinally ka use:-user ko lagta hai ki jab file open hua hai to file ko to close karna hi hoga, nahi to file open nahi hai ya is name ka file nahi hai to error chal jayega:-")

print("\nPROGRAM TYPE 1:'a+'mode me agar file me pahale se data hai to, file me new data bhi likh dega next me jo aap likhana chahte hai:-\n") 
try:     # ager sahi hoga to Try chal jayega 
    f = open("demofile4.txt","a+")  # 'a+'->mode me agar file me pahale se data hai to, file me new data bhi likh dega next me jo aap likhana chahte hai
    f.write("Wellecome my contory and most wellecome in india.")# ager sahi hoga to Try chal jayega
    #print("Show Data:",f.read())
    
except:  # nahi to except chaljayega
    print("Not Avilable File or Not Oppen file") 
finally:
    f.close() # file open hua to file ko closed karega hi,
