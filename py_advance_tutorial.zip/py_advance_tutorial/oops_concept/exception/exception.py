print("\n Excception:-user ko lagta hai ki error denewala hai,to error se bachane ke liye excception ka use kiya jata hai")

print("\nPROGRAM TYPE 1, Cheack Votting System Allowed For Vote:-") #---PRO ---1
a=input("Please Enter Your Age in Digite Number:\n")  
try:
    if int(a)>=18:
        print(f"YES, You Allowed for Votting, Because Your Age: {int(a)} >= 18")
    else:
        print(f"NO, Allowed for Votting, Because Your Age: {int(a)} < 18")
          
except Exception as error:
    print(error)                                                  #---PRO END----1
    
print("\nPROGRAM TYPE 2, Error handling throu user, Two Addition Value:-")     # -----PRO----2
a=input("Enter First number:\n")
b=input("Enter Second number:\n")
try:
    print(f"Total sum value:{int(a)+int(b)}")
except Exception as Error:
    print(Error)                                          #---PRO END----2