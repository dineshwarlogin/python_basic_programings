print("\nFinally ka use:-user ko lagta hai ki jab file open hua hai to file ko to close karna hi hoga, nahi to file open nahi hai ya is name ka file nahi hai to error chal jayega:-")

print("\nPROGRAM TYPE 1: File is Removed:-\n") 
import os
    # ager sahi hoga to Try chal jayega 
os.remove("demofile5.txt")  # 'a+'->mode me agar file me pahale se data hai to, file me new data bhi likh dega next me jo aap likhana chahte hai
f = open("demofile5.txt")
print("File deleted:",f)
