print()
print("This is Constructor and Deconstructor: Jab ham Object ko creat karte hai, tab hi constructor call ho jata hai,hame print karne \nka jarurat nahi parta hai:-")
class Dineshwar():
    def __init__(self):  # Constructor kaha jata hai
        print("Dineshwar paswan is constructor")
        
    def __del__(self):  # Deconstructor kaha jata hai
        print("Dineshwar paswan is Deconstructor")
        
Dineshwar()#Object ko creat karne se hi deconstructor call ho jata hai,hame print karne ki jarurat nahi parta hai,

        