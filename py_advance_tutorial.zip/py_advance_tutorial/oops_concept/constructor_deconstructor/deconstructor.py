print()
print("This is Deconstructor: Jab ham Object ko creat karte hai, tab hi constructor call ho jata hai,hame print karne \nka jarurat nahi parta hai:-")
class Dinesh():
    def __del__(self): #Deconstructor kaha jata hai
        print("Dineshwar paswan is a Software Engineer in Multinational Company")
        print("Helo my dear freinds")
        
        
Dinesh()#Object ko creat karne se hi constructor call ho jata hai,hame print karne ki jarurat nahi parta hai,

        