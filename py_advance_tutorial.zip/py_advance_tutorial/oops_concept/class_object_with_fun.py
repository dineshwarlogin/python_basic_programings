print()
print("Class is Define Data Type:-\n")

print("Program Type-1: I used class and fun/method with object:")
class Student():     # class kahate hai
    def Art_cource(self,name,cource,fee,batch): # function/method kahate hai
        self.name=name
        self.cource=cource
        self.fee=fee
        self.batch=batch
        return name,cource,fee,batch,
    

std1 = Student() # object kahte hai
 
print(std1.Art_cource("Dineshwar","BA",50500,"2021-2024"))
print(std1.Art_cource("Mahesh Agerwal","MA",850000,"2022-2024"))



