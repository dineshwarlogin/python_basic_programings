print()
print("Hybrid inheritance me Base class sabhi ka properties use karta hai:-\n")
class A():        # Super class
    STATMENT1
class B(A):       # Sub class1
    STATMENT2
    
class C(A):       # Sub class2
    STATMENT3
        
class D(B,C):     # Base class
    STATMENT4
    
    
D=D() #OBJECT 1, Base class, Sabhi class ka prpperties use karega
B=B() #OBJECT 2, Sub class1, Super class ka prpperties use karega
B=C() #OBJECT 3, Sub class2, Super class ka prpperties use karega