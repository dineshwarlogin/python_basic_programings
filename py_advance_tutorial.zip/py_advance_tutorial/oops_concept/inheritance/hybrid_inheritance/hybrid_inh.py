print()
print("Hybrid inheritance me Base class sabhi ka properties use karta hai:-\n")
class Techical:            # Super class
    def B_Tech(self):
        print("B.Tech Course in Technical")
class Non_Tech(Techical):    # Sub class1
    def BSC(self):
        print("BSC Course in Non Technical")
    
class Medical(Techical):     # Sub class2
    def Farma(self):
        print("Farma Course in Medical")
        
class Lla(Non_Tech,Medical):  # Base class
    def Llb(self):
        print("LLB Course in LLA")
    
    
L=Lla() #OBJECT 1, Base class, Sabhi class ka prpperties use karega
L.B_Tech()
L.BSC()
L.Farma()
L.Llb()
print("\nMedical, Super class ka properties use kar sakta hai, sath me apna bhi:-")
m=Medical() #OBJECT 2,
m.B_Tech()
m.Farma()
print("\nNon_Tech, Super class ka properties use kar sakta hai, sath me apna bhi:-")
N=Non_Tech() # OBJECT 3
N.B_Tech()
N.BSC()