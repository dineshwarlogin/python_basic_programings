class Computer():
    def Sony(self):
        print("Sony is brand name of Computer,and Computer is Super class")
    def Dell(self):
        print("Dell is brand name of Computer,and Computer is Super class")
class Software():
    def PDF(self):
        print("PDF is Software,and Software is Base class")
    def Excel(self):
        print("Excel is Software,and Software is Base class")
class Hardware(Computer,Software):
    def Printer(self):
        print("Printer is Hardware,and Hardware is Childe class")
    def CPU(self):
        print("CPU is Hardware,and Hardware is Childe class")
    pass
H=Hardware() # OBJECT 1, Childe class, Base class our Super class dono ka properties use kar sakta hai
print("\nBellow,Childe class, Base class our Super class dono ka properties use kar sakta hai:-\n")
H.Sony()
H.Dell()
H.PDF()
H.Excel()
H.Printer()
H.CPU()
print("\nBellow, Computer Super class hai, ye kewal khud ka peoperite use karega,nahi to error dega")
C=Computer()# OBJECT 2,Computer Super class hai, kewal khud ka peoperite use karega,
C.Dell()
C.Sony()
print("\nBellow, Software Base class hai, ye bhi kewal khud ka peoperite use karega,nahi to error dega")
S=Software() #OBJEC 3, Software Base class hai, ye bhi kewal khud ka peoperite use karega,nahi to error dega
S.PDF()
S.Excel()
        