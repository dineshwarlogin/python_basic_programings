class A:
    statements1
class B:
    statements2
class C(A,B):
    statements3
c1=C()
c1.statement1()
c1.statement2()
c1.statement3()