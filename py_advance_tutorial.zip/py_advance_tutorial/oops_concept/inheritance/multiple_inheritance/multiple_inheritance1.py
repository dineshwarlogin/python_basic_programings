class Computer(): # pareint class/super class hai
    def Sony(self):
        print("Sony is brand name of Computer,and Computer is Super class")
    def Dell(self):
        print("Dell is brand name of Computer,and Computer is Super class")

class Software(): # pareint class/super class hai
    def PDF(self):
        print("PDF is Software,and Software is Super class")
    def Excel(self):
        print("Excel is Software,and Software is Super class")

class Hardware(Computer,Software): #ye dono ka ka child class/Base class 
    def Printer(self):
        print("Printer is Hardware,and Hardware is Childe class")
    def CPU(self):
        print("CPU is Hardware,and Hardware is Childe class")
    pass
H=Hardware() # OBJECT 1, Childe class/ Base class hai ye dono Super class ka properties use kar sakta hai
print("\nBellow,Childe class/ Base class hai ye dono Super class ka properties use kar sakta hai:-\n")
try:                  # ager inme se koi bhi ak galti hua to
    H.Sony()
    H.Dell()
    H.PDF()
    H.Excel()
    H.Printer()
    H.CPU()
except Exception as error: # except chal jayega user ko error ka malum hojayega
    print("\n: ",error)

print("\nBellow, Computer Super class hai, ye kewal khud ka peoperite use karega,nahi to error dega")
C=Computer() # OBJECT 2,Computer Super class hai, kewal khud ka peoperite use karega,
try:             # ager inme se koi bhi ak galti hua to
    C.Dell()
    C.Sony()
    C.CPU()   # Error dega ager, Super class, Base class / Childe class ka properties use karega to:
    C.Excel() #  # Error dega ager, Super class, dusra super class ka properties use karega to:
except Exception as error: # except chal jayega user ko error ka malum hojayega
    print("\nType 1: ",error)

print("\nBellow, Software pairent/super class hai, ye bhi kewal khud ka peoperite use karega,nahi to error dega")
S=Software() #OBJEC 3,  Software Base class hai, ye bhi kewal khud ka peoperite use karega,nahi to error dega
try:
    S.PDF()
    S.Excel()
    S.Sony()   # Error dega ager, ak super class, dusra super class ka properties use nahi karega
except Exception as error: # except chal jayega user ko error ka malum hojayega
    print("\nType 2: ",error)

print("\nBellow,Error dega ager, Super class, Base class / Childe class ka properties use karega to:-")
try:
    C.PDF()      # Error dega ager, ak super class, dusra super class ka properties use nahi kar sakta hai
    C.Excel()    # Error dega ager, ak super class, dusra super class ka properties use nahi kar sakta hai
    C.Printer()  # Error dega ager, keoki super class, base class/childe class ka properties use nahi kar sakta hai     
except Exception as error: # except chal jayega user ko error ka malum hojayega
    print("\nType 3: ",error)


        