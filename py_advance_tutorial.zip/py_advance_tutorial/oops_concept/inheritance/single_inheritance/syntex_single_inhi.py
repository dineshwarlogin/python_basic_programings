class A:
    statements1
class B(A):
    statements2
B1=B()  # object
B1.statements1  #inherit kar sakta hai
B1.statements2
