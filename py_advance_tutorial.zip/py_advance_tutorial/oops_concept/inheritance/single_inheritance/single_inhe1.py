class Father(object):  # Super class kaha jata hai
    def Car(self):
        print("\nThis is Fater Car, Father is super class")
    def Mony(self):
        print("This is Father Mony,Father is super class")
    
class Childe(Father):    # Base/Childe class kaha jata hai
    def Bike(self):
        print("Childe of Bike, Childe is Base class")
    def Bala(self):
        print("Bala of Childe, Childe is Base class")
    pass
c=Childe() #object kahte hai, Base class, Super class ka our khud ka properties use kar sakta hai
print("Below, Base class, Super class ka our khud ka properties use kar sakta hai:-")
c.Car() # Father ka properti use kar sakta hai Childe Class 
c.Mony() # Fater ka properti use kar sakta hai Childe Class

c.Bike() # Base class khud ka bhi properites use karta hai
c.Bala()  # Base class khud ka bhi properites use karta hai

print("\nBelow, Father(Super class hai)kewal khud ko use kar sakta hai, Na ki Base class ka properties:-")
f=Father() #object, Super class hai,Super,Childe class ka properties use nahi kar sakta,Lekin khud ka use kar sakta hai
f.Car()# Super class hai,Super,Childe class ka properties use nahi kar sakta,Lekin khud ka use kar sakta hai 
f.Mony()#Super class hai,Super,Childe class ka properties use nahi kar sakta,Lekin khud ka use kar sakta hai

print("Below, error dega, Super class, Base class ka properties use kiya to:-\n")
f.Bike() # lekin Father(Father Super class hai,Super Childe class ka properties use nahi kar sakta) 
f.Bala()# lekin Father(Father Super class hai,Super Base class ka properties use nahi kar sakta)


