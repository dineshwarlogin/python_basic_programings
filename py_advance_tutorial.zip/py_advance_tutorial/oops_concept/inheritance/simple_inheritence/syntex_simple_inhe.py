class Computer:
    Statement 1
class Mobile:
    Statement 2
class Tv:
    Statement 3
    
c=Computer() # OBJECT 1, sabhi appne-appne properties use karega
m=Mobile()   # OBJECT 2, sabhi appne-appne properties use karega
t=Tv()       # OBJECT 3, sabhi appne-appne properties use karega