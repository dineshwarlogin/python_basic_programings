class Computer:
    def Safari(self):
        print("This is Safari oprating system of Computer")
        
class Mobile:
    def Dual(self):
        print("This is Dual sime of Mobile")
        
class Tv:
    def Hd(self):
        print("This is Hd high Quility of Tv")
    
c=Computer() # OBJECT 1, sabhi appne-appne properties use karega
print("\nBellow, Simple Inheritance me, Sabhi class appne-appne properties use karega:-\n")
c.Safari()

m=Mobile()   # OBJECT 2, sabhi appne-appne properties use karega
m.Dual()

t=Tv()       # OBJECT 3, sabhi appne-appne properties use karega
t.Hd()

class Calculater:
    def Add(self,a,b):
        return a+b
    def Sub(self,a,b):
        return a-b
    def Mul(self,a,b):
        return a*b
    def Div(self,a,b):
        return a/b
    def Moduleter(self,a,b):
        return a%b
C=Calculater() #OBJECT 4, sabhi appne-appne properties use karega 
print("\nProgram of Calculation:-")
print("A+B=",C.Add(50,80))
print("A-B=",C.Sub(500,80))
print("A*B=",C.Mul(20,10))
print("A/B=",C.Div(800,80))
print("A%B=",C.Moduleter(808,80))

