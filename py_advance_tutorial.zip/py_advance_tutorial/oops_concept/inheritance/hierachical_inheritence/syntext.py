class A():  #pairent class/super class kahte hai
    statment 1

class B(A):     #sub class kaha jata hai
    statment 2

class C(A):      # Base class kaha jata hai
    statment 3

C=C() # object 1
C.statment 1      # C class, kewal A class our khud ke class ka properties use karega
C.statment 2      # C class, kewal A class our khud ke class ka properties use karega

B=B() # object 2
B.statment 1      # B class, kewal A class our khud ke class ka properties use karega
B.statment 2      # B class, kewal A class our khud ke class ka properties use karega