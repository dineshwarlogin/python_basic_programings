print("\nHierachical Inheritence:- iska ak se adhik childe ho sakta hai, our sabhi pairent class ko inheritant kareg yani ki use karega,")
class  Employee():               # Employee ko Pairent class/Super class kaha jayega
    def Deparment1(self):        #method/function kaha jata hai
        print("\nDepatment 1 is Banking Sector")
    def Deparment2(self):        #method/function kaha jata hai
        print("Depatment 2 is Finance Sector")

class Government(Employee):        # Government ko Sub class kaha jayega
    def IT_Officer(self):          #method/function kaha jata hai
        print("IT officer Government Employee in Banking Sector!")
    def Security_Engineer(self):   #method/function kaha jata hai  
        print("Security Engineer Government Employee in Banking Sector!")

class Private(Employee):          # Private ko Base class kaha jayega
    def Excutive_Engineer(self):  #method/function kaha jata hai
        print("Excutive Engineer Private Employee in Finance Sector!")
    def Sellse_Manager(self):     #method/function kaha jata hai
        print("Sellse Manager Private Employee in Finance Sector! ")
    
p=Private() # object 1
try:
    p.Deparment1()         # Private class, kewal Employee class our khud ke class ka properties use karega
    p.Deparment2()         # Private class, kewal Employee class our khud ke class ka properties use karega
    p.Excutive_Engineer()  # Private class, kewal Employee class our khud ke class ka properties use karega
    p.Sellse_Manager()     # Private class, kewal Employee class our khud ke class ka properties use karega
    p.IT_Officer()
except Exception as Error: #
    print("\n",Error)
   
g=Government() # object 2
try:                      # agar sahi hoga proga to chal jayega
    g.Deparment1()        # Government class, kewal Employee class our khud ke class ka properties use karega
    g.Deparment2()        # Government class, kewal Employee class our khud ke class ka properties use karega
    g.IT_Officer()        # Government class, kewal Employee class our khud ke class ka properties use karega
    g.Security_Engineer() # Government class, kewal Employee class our khud ke class ka properties use karega
    g.Excutive_Engineer()
except Exception as Error: # warna bahut bara error dega, bhayank error se bachane ke liye use kiya jata ha,try and except ko 
    print("\n",Error)  