class GrandFather():      #Super class
    def Land(self):
        print("Land of Grand Father, GrandFathe is Super class")
class Father(GrandFather): # Sub class
    def House(self):
        print("House of Father, Fathe is Sub class")
class Childe(Father):       # Base class, 
    def Bike(self):
        print("Bike of Childe, Childe is Base class")
C=Childe() #object 1, Base class Sabhi ka properties use karega

print("\nBellow, Base class, Super class and Sub class our khud ka properties use karega:-")
C.Land() #Base class, Super class and Sub class our khud ka properties use karega
C.House() #Base class, Super class and Sub class our khud ka properties use karega
C.Bike()  #Base class, Super class and Sub class our khud ka properties use karega

print("\nBellow, Father kewal Super class our khud ka properties use karega:-")
F=Father() # OBJECT 2, kewal Super class our khud ka properties use karega
F.Land()
F.House()

print("\nBellow, GranFathe kewal khud ka properties use karega ,Na ki Sub class ya fir Base class:-")
GF=GrandFather() #OBJECT 3,Super class, Sub class ya Base class ka properties nahi use karega, kewal khud ka karega
GF.Land() #Super class, Sub class ya Base class ka properties nahi use karega kewal khud ka karega