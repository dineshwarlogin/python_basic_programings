print()
print("All,Any ka ham use bahut data me se odd/even ko janane ke liye use karte hai")
print()
evens=[8,2,10,4,]  # (x%2 ==0 or x%2 !=1) Even value cheack keliye
cheack=all([num%2 ==0 for num in evens]) 
print("Program type 1:- All data is Evens ?: ",cheack)

print()
evens=[8,2,10,4,9]  # (x%2 ==0 or x%2 !=1) Even value cheack keliye
cheack=all([num%2 !=1 for num in evens])
print("Program type 2:- All data is Evens ?: ",cheack)

print()
odds=[1,3,5,7,9]   # (x%2 ==1 or x%2 !=0) odd value cheack keliye
cheack=all([num%2 ==1 for num in odds])
print("Program type 3:- All data is Odds ?: ",cheack)

print()
odds=[1,3,5,7,9,2]  # (x%2 ==1 or x%2 !=0) odd value cheack keliye
cheack=all([num%2 ==0 for num in odds])
print("Program type 4:- All data is Odds ?: ",cheack)
