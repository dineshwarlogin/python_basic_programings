print()
print("All,Any ka ham use bahut data me se odd/even ko janane ke liye use karte hai")
print()
evens=[8,2,10,4] # (x%2 ==0 or x%2 !=1) Even value cheack keliye
cheack=any([num%2 ==1 for num in evens])
print("Program type 1:- Any fun, Sabhi data is evens [8,2,10,4] ? : ",cheack)

print()
evens=[8,2,10,4,5,9] # (x%2 ==0 or x%2 !=1) Even value cheack keliye
cheack=any([num%2 ==1 for num in evens])
print("Program type 2:- Any fun, Agar ak bhi data is odd [8,2,10,4,5,9]?: ",cheack)

print()
odds=[1,3,5,2] # (x%2 ==1 or x%2 !=0) odd value cheack keliye
cheack=any([num%2 ==0 for num in odds])
print("Program type 3:- Any fun, Agar ak bhi data is even [1,3,5,2] ?: ",cheack) # false print karega keoki koi ak value ko cheack karta hai ki T hai ki nahi

print()
odds=[1,3,5,7,9]  # (x%2 ==1 or x%2 !=0) odd value cheack keliye
cheack=any([num%2 ==0 for num in odds])
print("Program type 4:- Any fun, Sabhi data is odds [1,3,5,7,9] ?: ",cheack)

