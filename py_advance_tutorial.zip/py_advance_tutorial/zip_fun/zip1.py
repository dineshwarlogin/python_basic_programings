print("\nzip ka use:-ZIP ka use Compress karne ka use hota hai yani ki chota karna ya daba dena")
print("type 1:")
a=[4,50,78]
b=[0,3,40]
print("a=[4,50,78],b=[0,3,40] Tuple exchange in List: ",tuple(zip(a,b)))

print("\ntype 2:")
c=dict(zip(a,b))
print("a=[4,50,78],b=[0,3,40] Tuple exchange in Dict: ",c)

print("\ntype 3:")
a={4,50,78}
b={10,3}
c=tuple(zip(a,b))
print("a={4,50,78}, b={10,3} Dict exchange in Tuple: ",c)

print("\ntype 4:")
a={4,50,78}
b={10,3,8.09}
c=list(zip(a,b))
print("a={4,50,78}, b={10,3,8.09} Dict exchange in list: ",c)

print("\ntype 5:")
a=["Ram","HP","price"]
b=["4GB","Laptop", 50500]
c=dict(zip(a,b))
print('a=["Ram","HP","price"], b=["4GB","Laptop", 50500] list exchange in Dict:',c)

print("\ntype 6:")
a=["Ram","linex","price"]
b=["4GB","",50500]
c=dict(zip(a,b))
print('a=["Ram","linex","price"], b=["4GB","",50500] list exchange in Dict:',c)

print("\ntype 7:")
c=tuple(zip(a,b))
print('a=["Ram","linex","price"], b=["4GB","",50500] list exchange in tuple:',c)

print("\ntype 8:")
a=["Ram","linex","price"]
b=["4GB",5050.50]
c=dict(zip(a,b))
print('a=["Ram","linex","price"], b=["4GB",5050.50] List exchange in Dict:',c)