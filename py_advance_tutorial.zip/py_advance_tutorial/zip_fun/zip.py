print()
print("Zip data ko compress kar deta hai tuple me, yani ki daba deta hai")
print()

data1=[4,1,12,8]
data2=[4,1,12,8]
data=list(zip(data1,data2))
print("Program type1:- Zip fun, values in tuple inside list:",data)
print()

data1=(4,1,12,8,25)
data2=(4,1,12,8,25)
data=tuple(zip(data1,data2))
print("Program type2:- Zip fun, values in tuple inside tuple:",data)

print()
data1=[4,1,12,8,25]
data2=[4,1,12,8,25]
data=tuple(zip(data1,data2))
print("Program type3:- Zip fun, values in tuple inside tuple:",data)