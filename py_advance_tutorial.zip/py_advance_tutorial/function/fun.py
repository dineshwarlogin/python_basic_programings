print()
def add():  # simple funtion without airgement function
    a=12
    b=40
    c=a+b
    print("Without airgement function:",c)
    print("Helo Mirchi Ranchi Talivision")
add()
print()

def add_to_num(a,b): #argement function 
    c=a+b
    print("Two value with airgement: ",a ,"+", b,"=",c)
add_to_num(500,400)
add_to_num(600,400)
add_to_num(500,900)
add_to_num(800,300)
print()

def subtraction(a,b): #argement function
    c=a-b
    print("Two value with airgement:",a ,"-", b,"=",c)
subtraction(500,400)
subtraction(700,400)
print()

def subtraction(a,b): #argement function with return
    return a+b
c1 = subtraction(50,10)
print("Two airgement value with Return",c1)
c2 = subtraction(50,80)
print("Two airgement value with Return",c1)
        # OR
c = subtraction(20,10)
print("Two airgement value with Return",c)
c = subtraction(20,30)
print("Two airgement value with Return",c)
c = subtraction(30,30)
print("Two airgement value with Return",c)
c = subtraction(120,100)
print("Two airgement value with Return",c)
print()

def show(a):
    return a
show=show("Hello dear freinds")
print(show)

def show1(a,b):
    return a,b
show1=show1("my dear freinfs",80)
print(show1)

def show2(a,b):
    return a,b
show2=show2(50,80)
print(show2)

    
