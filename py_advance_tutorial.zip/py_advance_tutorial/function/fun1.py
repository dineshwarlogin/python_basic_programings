print()
print("# Maximume or Minimume comparition in 2 Values, in Function:-")
def max_2_values(a,b): # 2 maximum or manimmum value compration in function
    if a>b:
        print("A is greater than of B: ",a,">",b)
    else:
        print("A is less than of B: ",a,"<",b)
max_2_values(50,38)
max_2_values(80,18)
max_2_values(500,300)
max_2_values(80,538)
max_2_values(150,308)
max_2_values(850,838)
print()

print("# Find Maximume in Between 2 Values in Function:-")
def max_two_num(a,b):
    if a>b:
        return a
    else:
        return b
max=max_two_num(50,100)
print("This is Maximume Value:",max)
max=max_two_num(100,180)
print("This is Maximume Value:",max)
 
print()
print("# 3 Maximume in Between 3 Values in Function:-")
def max_3_val(a,b,c):
    if a>b:
        
        if a>c:
            return a
        else:
            return c
    else:
        if b>c:
            
            if b>a:
                return b
        else:
            return c
        
m=max_3_val(45,50,60)
m1=max_3_val(405,50,60)
print("This is a Maximume in 3 Values:",m)
print("This is a Maximume in 3 Values:",m1)
print()

print("Find Charecter:-")
def Sorting_cha():
    
    a="DINESHWAR"
    return a[2]
S=Sorting_cha()
print("Show Charecter:",S) 
print()

print("Find Last Charecter:-")
def last_char(a):
    return a[-1]

a="DINESHWAR"
    
print("Show Charecter:",last_char(a)) 
   