print()
 
def user_gessing():
    c=int(input("Enter cheack Currency: "))
  
    if (c==500 or c==2000 or c==1000):
        return c
            
currncy=user_gessing()

print("Currency is Available of:",currncy)
print()
while True:
    def find_cureny():
        c=int(input("Enter cheack Currency: "))
    
        if (c==500 or c==2000 or c==1000):
            print("Avilable Currence of:",c)
        else:
            print("Not Avilable Currence of:",c)
    find_cureny()
print()
    
  