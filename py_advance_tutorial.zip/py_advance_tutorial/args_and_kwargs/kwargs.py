print("\nkwargs ka use:- Ager bahut string ko print karna hai to args ka use karte hai, lekin kwargs olny dictionary value ko print karta hai;\n")

print("\nProgram Type 1:")
def Mobiles(*args,**kwargs):
    
    for i in args:

        print(i)
    print("\n")
    for item in kwargs:

        print(item)

Mob1 = {"APPLE":"MOBILE","REDMI":"HEADPHONE","RELMI":"ADOPTOR","INTEX":"MEMORY"}
Mob2 = {"METROLA":"Rs.5000","AIRCEL":"Rs.6800","MI":"Rs.3600","SAMSUNG":"Rs.4500","RELMI":"Rs.2400","APPO":"Rs.5060","VIVO":"Rs.6800"}
Mobiles(*Mob1,**Mob2)

print("\nProgram Type 2:")
def Cars(*args,**kwargs):
    
    for i in args:

        print(i)
    print("\n")
    for item in kwargs:

        print(item)

car1 = {"Audi":"Black","Suzzuki":"Wite","Honda":"Blue","XIUV":"Read","Tobera":"Green","Ford":"Read"}
car2 = ["BMW","Alto","Safari","Dastan","Clever","Hundai","Tata"]
Cars(*car2,**car1)

