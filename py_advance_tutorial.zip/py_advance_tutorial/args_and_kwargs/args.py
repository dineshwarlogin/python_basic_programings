
from typing import Type


print("\nargs ka use:- Ager bahut string ko print karna hai to args ka use karte hai;\n")
print("Program Type 1:")
def Mobile(a,b,c,d,e):

    print(a,b,c,d,e)

Mobile("APPLE","SONY","REDMI","SAMSUNG","RELMI")
 
print("\nPROGRAM TYPE 2 args: collection of Mobil with list and forloopin args;")
def Mobile(*args):

    for item in args:

        print(item)

Mob=["APPLE","SONY","REDMI","SAMSUNG","RELMI","APPO","INTEX","NOKIA",00,0.89,678,"VIVO"]
Mobile(*Mob)

print("\nPROGRAM TYPE 3, arsg: collection of Cars with tuple and forloop in args;")
def Cars(*args):

    for item in args:

        print(item)

CR=("HONDAI","DASTAN","SAFARI","AUDI","SUZZUKI","FORDE","XIUV","TATA",90,68.08,"MAHINDAR",50.80,0.8,65)
Cars(*CR)

print("\nPROGRAM TYPE 4, arsg: collection of laptop with dictionary and forloop in args: arsg print data in dictionary")
def Laptops(*arsg):
    for i in arsg:
        print(i)
lpt={"Laptop":"Sony","Ram":"4gb","Hard_disk":"500gb"},{"Laptop":"Del","Ram":"3gb","Hard_disk":"250gb"},{"Laptop":"Accer","Ram":"2gb","Hard_disk":"50gb"},{"Laptop":"hp","Ram":"1gb","Hard_disk":"200gb"}
Laptops(*lpt)

print("\nPROGRAM TYPE 5, arsg: collection of laptop with dictionary and forloop in args: arsg print data in dictionary")
def Laptops(*arsg):
    for data in arsg:
        print(data)
lpt={"Laptop":"Sony","Ram":"4gb","Hard_disk":"500gb","Mobile":"Redmi","Price":"Rs.5000","Camra":"25mega fixel"}
Laptops(*lpt)
     




    