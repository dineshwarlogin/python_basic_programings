print("\nkwargs ka use:- Ager bahut string ko print karna hai to args ka use karte hai, lekin kwargs olny dictionary value ko print karta hai;\n")

print("Program Type 1:")
def Computers(a,*args,**kwargs):
    print(a)
    for i in args:
        print(i)
    print("\n")
    for Key in kwargs:
        print(Key)

a=("Windos10")
Comp = ["CHIP","HEADPHONE","ADOPTOR","MEMORY"]
Comp2 = {"ACCER":"Rs.50500","INTEX":"Rs.60800","LENOVO":"Rs.30600","SAMSUNG":"Rs.40500","HP":"Rs.24000"}
Computers(a,*Comp,**Comp2)

print("\nProgram Type 2:")
def Computers(a,*args,**kwargs):
    print(a)
    for i in args:
        print(i)
    print("\n")
    for Key,value in kwargs.deta():
        print(Key,value)

a=("Windos10","Ram:4gb","Rs.75000")
Comp = ["CHIP","HEADPHONE","ADOPTOR","MEMORY"]
Comp2 = {"ACCER":"Rs.50500","INTEX":"Rs.60800","LENOVO":"Rs.30600","SAMSUNG":"Rs.40500","HP":"Rs.24000"}
Computers(a,*Comp,**Comp2)

