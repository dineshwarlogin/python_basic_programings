from typing import Tuple


print()
print("Filter me check karte hai Odd/Even value ko")
print()

data=[4,1,12,8,25,36,13,15,39,20,28,5,53,76,89.50,103,107,102,114]
data=list(filter(lambda x: x%2 ==0,data)) # (x%2 ==0 or x%2 !=1) Even value cheack keliye
print("Program 1:- Filter Even values in list:",data)
print()

data1=[4,1,12,8,25,36,13,15,39,20,28,5,53,76,89.50,103,107,102,114]
data1=tuple(filter(lambda x: x%2 !=0,data1)) # (x%2 ==1 or x%2 !=0) odd value cheack keliye
print("Program 2:- Filter ODD values in Tuple:",data1)
print()

data1=(4,1,12,8,25,36,13,15,39,20,28,107,102,114)
data1=list(filter(lambda x: x%2 ==1,data1)) # (x%2 ==1 or x%2 !=0) odd value cheack keliye
print("Program 3:- Filter ODD values in list:",data1)

print()

data1=[4,1,12,8,25,36,13,15,39,20,28,107,102,114]
data1=tuple(filter(lambda x: x%2 !=1,data1)) # (x%2 ==0 or x%2 !=1) Even value cheack keliye
print("Program 4:- Filter Even values in tuple:",data1)
