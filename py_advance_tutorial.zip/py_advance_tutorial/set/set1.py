data={10,20,10,20,30,40} # set me nakal ko 1 hi manta hai, chahe jitne bhi nakal ho
print("This is a:",type(data))
print("This is a set of unieq value:",data)

data1={80,50,40,30,20}
d=data.intersection(data1) # Intersection is Commone value between two Set
print("Intersection is Commone value between two Set:",d)

data2={100,70,50,40,30}
d1=data1.union(data2) # Union is unieq value between two Set,match kiya jo nahi match kiya obhi print karega
print("Union is unieq value between two Set:",d1)

d2=data.difference(data2) # dono set me jo comon nahi hai,jo match nahi kiya ho, 
print("difference value between two Set:",d2)

d3=data1.difference(data2)
print("Difference between two set:",d3)
print()

d1.clear()
print("Clear set data d1:",d1)
d2.clear()
print("Clear set data d2:",d2)
d3.clear()
print("Clear set data d3:",d3)
data.clear()
print("Clear set data:",data)

print()
d5={1,2,3,4,1,2,3,4,} 
d6={1,3,4,5,6,}
d7= d5 | d6  # union me unieq value hota hai, 2 set me se, hai, jo pair me data hai o bhi ak bar hi,jo nahi pair me o bhi print karega
print("This is union:",d7)
d7= d5 & d6  # intersection me commone value print karega dono set me se
print("This is intersection, intersection me commone value print karega dono set me se:",d7)
