print()
print("set me kuchi data stor kar sakte hai, But:list,tuple,dic ko nahi,")
data={} #dictionay
print("This is a: ",type(data))

data={10,20,30,40,50,50.00,30,20,10,60,70,15,"raju","mohan","sudhir",55.6,9.08} # set,  set is collaction of unieqe data like:- 1,2,3,4
print("This is a: ",type(data))
print("This is a Set, and Set is collaction of unieqe data :",data)

data1=(2,0) # tuple
print("This is a:",type(data1))

print("tuple exchange in  set:",set(data1))

data2=[23,"an"]    # list
print("This is a: ",type(data2))

data3= set(data2)    #list exchange in set
print("list exchange in : ",type(data3))

print()
data4={"ram","mohan","sohan","raju",50,30,10.0,"ram","mohan","ghansyam","radha",30,70,15} #set
print("Set is collaction of unieqe data: ",data4)

print()
for i in data4: # for loop with set function
    print("for loop with set function:",i)
print() 
if "sohan" in data4:         # in keyword
    print("Yes, persented")
else:
    print("No,persented")
print()
data4.add("Raju") # AK Value ko add kar sakte ho
print("Add fun, Raju is added:",data4)
data4.remove("ghansyam") # remove hojayega yani ki delet 
print("ghansyam is removed in set :",data4)
data4.intersection(data) # dono set me ka value jo match karega,   
print("Intersection is collection of commone data in two set:",data4)
data4.union(data)
print("union is collection of unieq data in 2 set:",data4)
data4.clear()
print("This clear set:",data4)